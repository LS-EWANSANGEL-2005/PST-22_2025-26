/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main {
    public static void main(String[] args) {
        int num1 = 20;
        int num2 = 10;
        int result;
        result = num1 + num2;
        System.out.println(num1 + " + " + num2 + " = " + result);
        result = num1 - num2;
        System.out.println(num1 + " - " + num2 + " = " + result);
        result = num1 * num2;
        System.out.println(num1 + " * " + num2 + " = " + result);
        result = num1 / num2;
        System.out.println(num1 + " / " + num2 + " = " + result);
        int num3 = 7;
        int num4 = 2;
        result = num3 / num4;
        System.out.println(num3 + " / " + num4 + " = " + result);
        result = num3 % num4;
        System.out.println(num3 + " % " + num4 + " = " + result);
    }
}
